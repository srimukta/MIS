﻿//Author: Srimukta Pisupati
//Date: 02/16/2024
//Assignment: Homework 2

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Pisupati_Srimukta_HW2.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Pisupati_Srimukta_HW2.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult CheckoutGroup()
        {
            return View();
        }
        public IActionResult GroupTotals(GroupOrder groupOrder)
        {
            if (!ModelState.IsValid)
            {
                return View("CheckoutGroup", groupOrder);
            }

            groupOrder.CustomerType = CustomerType.Group;
            groupOrder.CalcTotals();

            return View(groupOrder);
        }
        public IActionResult CheckoutIndividual()
        {
            return View();
        }
        public IActionResult IndividualTotals(IndividualOrder individualOrder)
        {
            if (!ModelState.IsValid)
            {
                return View("CheckoutIndividual", individualOrder);
            }

            individualOrder.CustomerType = CustomerType.Individual;
            individualOrder.CalcTotals();

            return View(individualOrder);
        }
    }
}

