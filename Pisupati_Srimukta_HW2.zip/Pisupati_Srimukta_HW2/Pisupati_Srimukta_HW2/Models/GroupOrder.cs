﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Pisupati_Srimukta_HW2.Models
{
    public class GroupOrder : Order
    {

        [Display(Name = "Preferred Customer:")]
        public Boolean PreferredCustomer { get; set; }

        [Display(Name = "Setup Fee:")][Required(ErrorMessage = "Setup fee required.")][DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SetupFee { get; set; }

        public void CalcTotals()
        {
            try
            {
                CalcSubtotals();
            }
            catch (Exception x)
            {
                throw new Exception("Subtotal Error", x);
            }
            if (PreferredCustomer || Subtotal > 5000)
            {
                SetupFee = 0;
                PreferredCustomer = true;
            }

            Total = Subtotal + SetupFee;

        }
    }
}

