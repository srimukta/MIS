﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860
namespace Pisupati_Srimukta_HW2.Models
{
    public enum CustomerType
    {
        Group, Individual
    }

    public abstract class Order : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
        protected const decimal SWEATSHIRT_PRICE = 15;
        protected const decimal TSHIRT_PRICE = 10;

        [Required(ErrorMessage = "Organization code is required.")]
        [StringLength(6, MinimumLength = 4, ErrorMessage = "Organization code must be between 4 and 6 characters.")]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Organization code must contain only letters.")]
        public required string OrganizationCode { get; set; }

        [Required(ErrorMessage = "Customer type is required.")]
        public CustomerType CustomerType { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Number of sweatshirts must be a non-negative integer.")]
        public int NumberOfSweatshirts { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Number of t-shirts must be a non-negative integer.")]
        public int NumberOfTShirts { get; set; }

        public int TotalItems { get; set; }
        public decimal SweatshirtSubtotal { get; set; }
        public decimal TShirtSubtotal { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Total { get;  set; }


        public void CalcSubtotals()
        {
            if (TotalItems == 0)
            {
                throw new InvalidOperationException("Total items cannot be zero.");
            }

            SweatshirtSubtotal = NumberOfSweatshirts * SWEATSHIRT_PRICE;
            TShirtSubtotal = NumberOfTShirts * TSHIRT_PRICE;
            Subtotal = SweatshirtSubtotal + TShirtSubtotal;
        }
    }
}


