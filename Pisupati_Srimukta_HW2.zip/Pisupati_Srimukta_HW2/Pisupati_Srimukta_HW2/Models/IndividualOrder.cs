﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Pisupati_Srimukta_HW2.Models
{
	public class IndividualOrder:Order
	{
        private const decimal SALES_TAX_RATE = 0.0875m;
        private const decimal SWEATSHIRT_FEE = 2.50m;
        private const decimal TSHIRT_FEE = 2.00m;

        [Display(Name = "Customer Name:")] public String? CustomerName { get; set; }
        [Display(Name = "Processing Fee:")][DisplayFormat(DataFormatString = "{0:c}")] public Decimal ProcessingFee { get; set; }
        [Display(Name = "Sales Tax:")][DisplayFormat(DataFormatString = "{0:c}")] public Decimal SalesTax { get; set; }

        public void CalcTotals()
        {
            try
            {
                CalcSubtotals();
            }
            catch (Exception x)
            {
                throw new Exception("Subtotal Error", x);
            }

            ProcessingFee = NumberOfSweatshirts * SWEATSHIRT_FEE + NumberOfTShirts * TSHIRT_FEE;
            SalesTax = (Subtotal + ProcessingFee) * SALES_TAX_RATE;

            Total = Subtotal + ProcessingFee + SalesTax;
        }
    }
}

